# gentoo-qemu-rv64

Fork of [qemus/qemu](https://github.com/qemus/qemu) extended with:

- **RISC-V 64** Gentoo via official `di-rv64_lp64d-console` qcow2 installer
- **qcow2 → EFI ISO** pipeline (adapted from [brandonrc/qemu2liveiso](https://github.com/brandonrc/qemu2liveiso))
- **binfmt_misc** registration for rv64 + arm64 (via `qemu-user-static`)
- **arch-chroot** / **genfstab** support for chroot operations inside rv64 rootfs
- **iPXE** multi-arch build script (x86_64, arm64, riscv64-experimental)
- All outputs mounted to `./output/` on the host

## Services

| Service | Port | Profile | Purpose |
|---------|------|---------|---------|
| `qemu-gentoo` | 8006 | `amd64` | Standard amd64 Gentoo via qemux/qemu |
| `qemu-rv64` | 8007 | `rv64` | RISC-V 64 Gentoo, qemu-system-riscv64 |
| `qcow2-to-iso` | — | `iso` | One-shot: dumps rv64 qcow2 → EFI ISO |

## Quick Start

```bash
# Clone and set up
git clone https://github.com/necrose99/gentoo-qemu-rv64
cd gentoo-qemu-rv64
cp .env .env.local   # customise RV64_QCOW2_URL, RAM_SIZE etc.
mkdir -p output qemu/amd64 qemu/rv64

# Run amd64 Gentoo (standard)
docker compose --profile amd64 up -d
# → http://localhost:8006

# Run RISC-V 64 Gentoo (fetches qcow2 on first run)
docker compose --profile rv64 up -d
# → console via: docker compose logs -f qemu-rv64
# → SSH once Gentoo is installed: ssh -p 2222 root@localhost

# Dump installed rv64 qcow2 → bootable EFI ISO
# (run AFTER installing Gentoo to the main disk)
docker compose run --rm qcow2-to-iso
# → ./output/gentoo-rv64-live.iso
```

## File Layout

```
.
├── docker-compose.yaml
├── rv64.Dockerfile          # qemu-rv64 service image
├── iso-builder.Dockerfile   # qcow2-to-iso sidecar image
├── .env                     # default env vars
├── scripts/
│   ├── rv64-start.sh        # entrypoint: fetch + launch qemu-system-riscv64
│   ├── fetch-rv64-qcow2.sh  # download + verify Gentoo rv64 qcow2
│   ├── setup-binfmt.sh      # register riscv64/aarch64 binfmt_misc entries
│   ├── qcow2-to-iso.sh      # qcow2 → EFI ISO pipeline
│   └── ipxe-build.sh        # iPXE multi-arch build + embed boot script
├── qemu/
│   ├── amd64/               # amd64 VM storage (persistent)
│   └── rv64/                # rv64 VM storage + cached qcow2
└── output/                  # ← ISO, squashfs, iPXE binaries land here
```

## RISC-V KVM Notes

KVM acceleration for RISC-V requires:
- Host kernel ≥ 6.2 with `CONFIG_KVM_RISCV=y`
- CPU with the **H-extension** (hypervisor extension)

Without KVM the container automatically falls back to **TCG multi-thread** emulation — functional but slow (~50–100 MHz effective throughput).

## qcow2 → EFI ISO Pipeline

`scripts/qcow2-to-iso.sh` (adapted from brandonrc/qemu2liveiso) performs:

1. `modprobe nbd` + `qemu-nbd --connect` to expose qcow2 partitions
2. Auto-detects root partition by fstype
3. `genfstab -U` for reference fstab
4. Optional `arch-chroot` + `dracut` initramfs rebuild (requires binfmt_misc for rv64)
5. `mksquashfs` rootfs → `LiveOS/squashfs.img`
6. `grub-mkstandalone` → `BOOTRISCV64.EFI` (or x86_64/arm64)
7. `xorriso` → bootable EFI ISO with GRUB2 menu
8. Output → `./output/gentoo-rv64-live.iso`

## iPXE

```bash
# Build iPXE with embedded Gentoo rv64 chainload script
docker compose run --rm qcow2-to-iso bash /scripts/ipxe-build.sh

# Output in ./output/ipxe/:
#   undionly-gentoo-rv64.kpxe   (x86_64 BIOS chainload)
#   ipxe-x86_64.efi
#   ipxe-arm64.efi
#   ipxe-riscv64.efi            (experimental)
```

Edit `EMBED_SCRIPT` in `ipxe-build.sh` to point `server-ip` at your PXE server.

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `RV64_QCOW2_URL` | 20260406 build | Gentoo rv64 qcow2 URL or `auto` |
| `DISK_SIZE` | `32G` | rv64 main disk size |
| `RAM_SIZE` | `4G` | rv64 VM RAM |
| `CPU_CORES` | `4` | rv64 VM CPUs |
| `GENTOO_MIRROR` | distfiles.gentoo.org | Mirror for auto-resolve |
| `SKIP_DRACUT` | `0` | Set `1` to skip initramfs rebuild |
| `SQUASHFS_COMP` | `xz` | Squashfs compressor (`xz`, `zstd`, `lzo`) |
