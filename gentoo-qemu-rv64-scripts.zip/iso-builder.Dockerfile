# iso-builder.Dockerfile
# Sidecar image used by both qcow2-to-iso and ipxe-builder services.
# Contains the full toolchain needed to:
#   - Mount XFS/btrfs/ext4 qcow2 via nbd
#   - Extract rootfs, kernel, initramfs
#   - chroot (with binfmt_misc for rv64/arm64) and rebuild dracut initramfs
#   - Build squashfs → EFI ISO via xorriso + GRUB2
#   - Compile iPXE for x86_64/arm64/riscv64 targets

FROM ubuntu:24.04

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update && apt-get install -y --no-install-recommends \
    \
    # ── QEMU / nbd ────────────────────────────────────────────────────────
    qemu-utils \
    qemu-user-static \
    nbd-client \
    \
    # ── Filesystem tools ──────────────────────────────────────────────────
    xfsprogs \
    btrfs-progs \
    e2fsprogs \
    dosfstools \
    parted \
    gdisk \
    util-linux \
    \
    # ── squashfs + ISO ────────────────────────────────────────────────────
    squashfs-tools \
    xorriso \
    mtools \
    genisoimage \
    isolinux \
    \
    # ── GRUB2 multi-arch EFI ─────────────────────────────────────────────
    grub2-common \
    grub-efi-amd64-bin \
    grub-efi-arm64-bin \
    grub-efi-riscv64-bin \
    grub-pc-bin \
    \
    # ── arch-install-scripts (arch-chroot + genfstab) ─────────────────────
    arch-install-scripts \
    \
    # ── libguestfs (guestmount fallback) ─────────────────────────────────
    libguestfs-tools \
    \
    # ── iPXE build deps ───────────────────────────────────────────────────
    git \
    make \
    gcc \
    gcc-aarch64-linux-gnu \
    gcc-riscv64-linux-gnu \
    binutils \
    binutils-aarch64-linux-gnu \
    binutils-riscv64-linux-gnu \
    liblzma-dev \
    zlib1g-dev \
    \
    # ── General ───────────────────────────────────────────────────────────
    wget curl rsync bash \
    python3 \
    xz-utils zstd lzma cpio \
    \
  && rm -rf /var/lib/apt/lists/*

COPY scripts/setup-binfmt.sh  /usr/local/bin/setup-binfmt.sh
COPY scripts/qcow2-to-iso.sh  /usr/local/bin/qcow2-to-iso.sh
COPY scripts/ipxe-build.sh    /usr/local/bin/ipxe-build.sh

RUN chmod +x \
    /usr/local/bin/setup-binfmt.sh \
    /usr/local/bin/qcow2-to-iso.sh \
    /usr/local/bin/ipxe-build.sh

RUN mkdir -p /storage /output /tmp/isobuild

VOLUME ["/storage", "/output"]

ENTRYPOINT ["/usr/local/bin/qcow2-to-iso.sh"]
