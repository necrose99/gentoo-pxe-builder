#!/bin/bash
# ipxe-build.sh  v2
# Builds iPXE for x86_64 (BIOS + EFI), arm64-efi, riscv64-efi (experimental)
# with an embedded Gentoo LiveUSB-compatible boot script baked in.
#
# Gentoo PXE kernel cmdline (from wiki.gentoo.org/wiki/Installation_alternatives):
#   root=/dev/ram0 init=/linuxrc looptype=squashfs loop=/image.squashfs cdroot
# For dracut-based live images add:
#   rd.live.dir=/ rd.live.squashimg=image.squashfs
#
# Usage:
#   docker compose run --rm ipxe-builder
#   TARGETS="x86_64 arm64" docker compose run --rm ipxe-builder

set -euo pipefail

IPXE_GIT="https://github.com/ipxe/ipxe.git"
IPXE_SRC="/tmp/ipxe"
OUTPUT_DIR="${OUTPUT_DIR:-/output}/ipxe"
TARGETS="${TARGETS:-x86_64 arm64}"
PXE_SERVER="${PXE_SERVER:-192.168.1.10}"

die()  { echo "ERROR: $*" >&2; exit 1; }
info() { echo "[ipxe-build] $*"; }

mkdir -p "${OUTPUT_DIR}"

# ── Install build deps ────────────────────────────────────────────────────────
info "Checking build dependencies..."
MISSING=()
for cmd in make gcc git; do
    command -v "${cmd}" &>/dev/null || MISSING+=("${cmd}")
done
if [[ ${#MISSING[@]} -gt 0 ]]; then
    info "Installing: ${MISSING[*]}"
    apt-get update -qq && apt-get install -y --no-install-recommends \
        "${MISSING[@]}" \
        liblzma-dev zlib1g-dev \
        gcc-aarch64-linux-gnu binutils-aarch64-linux-gnu \
        gcc-riscv64-linux-gnu  binutils-riscv64-linux-gnu \
    2>/dev/null || info "[warn] apt install incomplete"
fi

# ── Clone / update iPXE ──────────────────────────────────────────────────────
if [[ ! -d "${IPXE_SRC}/.git" ]]; then
    info "Cloning iPXE..."
    git clone --depth=1 "${IPXE_GIT}" "${IPXE_SRC}"
else
    info "Updating iPXE..."
    git -C "${IPXE_SRC}" pull --ff-only 2>/dev/null || true
fi

# ── Embedded boot script ──────────────────────────────────────────────────────
# Follows Gentoo wiki kernel cmdline conventions:
# Traditional (linuxrc-based): loop=/image.squashfs looptype=squashfs cdroot
# Dracut live:                 rd.live.dir=/ rd.live.squashimg=image.squashfs cdroot
EMBED_SCRIPT="${IPXE_SRC}/gentoo-rv64.ipxe"
cat > "${EMBED_SCRIPT}" <<IPXESCRIPT
#!ipxe
# Gentoo Linux RISC-V 64 PXE boot
# Adjust server-ip to your PXE/HTTP server address.
# Kernel + initramfs served from http://<server>/gentoo-pxe/rv64/

set server-ip  ${PXE_SERVER}
set base-url   http://\${server-ip}/gentoo-pxe

echo =========================================
echo  Gentoo Linux PXE Boot
echo  Server: \${server-ip}
echo =========================================

:rv64
kernel \${base-url}/rv64/gentoo-rv64 \\
       root=/dev/ram0 init=/linuxrc \\
       looptype=squashfs loop=/image.squashfs cdroot \\
       rd.live.dir=/ rd.live.squashimg=image.squashfs \\
       console=ttyS0,115200n8 net.ifnames=0
initrd \${base-url}/rv64/gentoo-rv64.igz
boot || goto shell

:amd64
kernel \${base-url}/amd64/gentoo \\
       root=/dev/ram0 init=/linuxrc \\
       looptype=squashfs loop=/image.squashfs cdroot \\
       rd.live.dir=/ rd.live.squashimg=image.squashfs \\
       nodhcp secureconsole
initrd \${base-url}/amd64/gentoo.igz
boot || goto shell

:shell
echo Boot failed — dropping to iPXE shell
shell
IPXESCRIPT

info "Embedded script: ${EMBED_SCRIPT}"

# ── Build function ────────────────────────────────────────────────────────────
build_target() {
    local TARGET="$1"
    cd "${IPXE_SRC}/src"
    make clean 2>/dev/null || true

    case "${TARGET}" in
        x86_64)
            info "Building x86_64 BIOS (undionly.kpxe)..."
            make bin/undionly.kpxe \
                EMBED="${EMBED_SCRIPT}" -j"$(nproc)" 2>&1 | tail -3
            cp bin/undionly.kpxe "${OUTPUT_DIR}/undionly-gentoo.kpxe"

            info "Building x86_64 EFI (ipxe.efi)..."
            make bin-x86_64-efi/ipxe.efi \
                EMBED="${EMBED_SCRIPT}" -j"$(nproc)" 2>&1 | tail -3
            cp bin-x86_64-efi/ipxe.efi "${OUTPUT_DIR}/ipxe-x86_64.efi"

            info "x86_64: undionly-gentoo.kpxe + ipxe-x86_64.efi"
            ;;

        arm64)
            if ! command -v aarch64-linux-gnu-gcc &>/dev/null; then
                info "[skip] arm64: aarch64-linux-gnu-gcc not found"
                return 0
            fi
            info "Building arm64 EFI (snp.efi)..."
            make bin-arm64-efi/snp.efi \
                CROSS_COMPILE=aarch64-linux-gnu- \
                EMBED="${EMBED_SCRIPT}" -j"$(nproc)" 2>&1 | tail -3 \
            && cp bin-arm64-efi/snp.efi "${OUTPUT_DIR}/ipxe-arm64.efi" \
            && info "arm64: ipxe-arm64.efi" \
            || info "[warn] arm64 EFI build failed"
            ;;

        riscv64)
            # iPXE riscv64-efi is experimental upstream.
            # Requires gcc-riscv64-linux-gnu and the riscv64-efi platform patch.
            if ! command -v riscv64-linux-gnu-gcc &>/dev/null; then
                info "[skip] riscv64: riscv64-linux-gnu-gcc not found"
                return 0
            fi
            info "Building riscv64 EFI (experimental)..."
            make bin-riscv64-efi/snp.efi \
                CROSS_COMPILE=riscv64-linux-gnu- \
                EMBED="${EMBED_SCRIPT}" -j"$(nproc)" 2>&1 | tail -5 \
            && cp bin-riscv64-efi/snp.efi "${OUTPUT_DIR}/ipxe-riscv64.efi" \
            && info "riscv64: ipxe-riscv64.efi (experimental)" \
            || info "[warn] riscv64 iPXE build failed — this is expected upstream"
            ;;

        *)
            info "[skip] Unknown target: ${TARGET}"
            ;;
    esac
}

# ── Build all targets ─────────────────────────────────────────────────────────
for T in ${TARGETS}; do
    build_target "${T}"
done

# ── Summary ───────────────────────────────────────────────────────────────────
section() { echo; echo "━━━ $* ━━━"; }
section "iPXE Build Summary"
ls -lh "${OUTPUT_DIR}/" 2>/dev/null | grep -v '^total' || true

echo
echo "── TFTP server layout ───────────────────────────────────────"
echo "  /tftpboot/"
echo "    pxelinux.cfg/default      → chainload to ipxe"
echo "    undionly-gentoo.kpxe      → x86_64 BIOS chainloader"
echo "    ipxe-x86_64.efi           → x86_64 UEFI"
echo "    ipxe-arm64.efi            → arm64 UEFI"
echo "    ipxe-riscv64.efi          → riscv64 UEFI (experimental)"
echo
echo "── HTTP server layout ───────────────────────────────────────"
echo "  http://${PXE_SERVER}/gentoo-pxe/"
echo "    amd64/gentoo              kernel"
echo "    amd64/gentoo.igz          initramfs"
echo "    amd64/image.squashfs      squashfs root"
echo "    rv64/gentoo-rv64          kernel"
echo "    rv64/gentoo-rv64.igz      initramfs"
echo "    rv64/image.squashfs       squashfs root"
echo
echo "── GRUB2 netboot snippet (EFI, server-side) ────────────────"
cat <<'EOF'
menuentry "Gentoo amd64 PXE" {
    linux  (tftp)/gentoo-pxe/amd64/gentoo root=/dev/ram0 init=/linuxrc \
           looptype=squashfs loop=/image.squashfs cdroot \
           rd.live.dir=/ rd.live.squashimg=image.squashfs nodhcp secureconsole
    initrd (tftp)/gentoo-pxe/amd64/gentoo.igz
}
EOF
