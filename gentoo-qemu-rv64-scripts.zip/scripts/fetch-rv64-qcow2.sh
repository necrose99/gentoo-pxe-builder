#!/bin/bash
# fetch-rv64-qcow2.sh
# Downloads the Gentoo RISC-V 64 installer qcow2.
# Usage: fetch-rv64-qcow2.sh <URL|auto> <destination_path>
#
# "auto" queries distfiles.gentoo.org/releases/riscv/autobuilds/
# for the latest di-rv64_lp64d-console qcow2.

set -euo pipefail

MIRROR="${GENTOO_MIRROR:-https://distfiles.gentoo.org}"
RISCV_BASE="${MIRROR}/releases/riscv/autobuilds"

URL="${1:-auto}"
DEST="${2:-/storage/gentoo-rv64-installer.qcow2}"
DESTDIR=$(dirname "${DEST}")

die()  { echo "ERROR: $*" >&2; exit 1; }
info() { echo "[fetch-rv64] $*"; }

mkdir -p "${DESTDIR}"

# ── Auto-resolve latest ──────────────────────────────────────────────────────
if [[ "${URL}" == "auto" ]]; then
    info "Querying ${RISCV_BASE}/latest-builds.txt ..."

    # Try latest-builds.txt first (newer), fall back to latest-stage3.txt
    LATEST_TXT=$(curl -fsSL "${RISCV_BASE}/latest-builds.txt" 2>/dev/null) \
        || LATEST_TXT=$(curl -fsSL "${RISCV_BASE}/latest-stage3.txt" 2>/dev/null) \
        || die "Could not fetch build listing from ${RISCV_BASE}"

    # Lines look like:  20260406T163102Z/di-rv64_lp64d-console-20260406T163102Z.qcow2 <size> <sha512>
    LATEST_PATH=$(printf '%s\n' "${LATEST_TXT}" \
        | grep -v '^#' \
        | grep "di-rv64.*lp64d.*\.qcow2$" \
        | head -1 \
        | awk '{print $1}')

    [[ -z "${LATEST_PATH}" ]] && die \
        "No di-rv64_lp64d qcow2 found in latest-builds.txt. Set RV64_QCOW2_URL explicitly."

    URL="${RISCV_BASE}/${LATEST_PATH}"
    info "Resolved latest: ${URL}"
fi

BASENAME=$(basename "${URL}")
DEST_FINAL="${DESTDIR}/${BASENAME}"

# ── Skip if already fully cached ─────────────────────────────────────────────
if [[ -f "${DEST_FINAL}" ]]; then
    REMOTE_SIZE=$(curl -fsSI "${URL}" 2>/dev/null \
        | grep -i '^content-length:' | tail -1 \
        | tr -d '\r ' | cut -d: -f2)
    LOCAL_SIZE=$(stat -c%s "${DEST_FINAL}" 2>/dev/null || echo 0)

    if [[ -n "${REMOTE_SIZE}" && "${REMOTE_SIZE}" == "${LOCAL_SIZE}" ]]; then
        info "Cache hit: ${DEST_FINAL} (${LOCAL_SIZE} bytes). Skipping download."
        # Ensure the expected destination symlink/path is correct
        [[ "${DEST}" != "${DEST_FINAL}" ]] && ln -sf "${DEST_FINAL}" "${DEST}"
        exit 0
    fi
    info "Size mismatch (local=${LOCAL_SIZE} remote=${REMOTE_SIZE}). Re-downloading."
fi

# ── Download ──────────────────────────────────────────────────────────────────
info "Downloading: ${URL}"
info "         → : ${DEST_FINAL}"
wget --progress=bar:force:noscroll -O "${DEST_FINAL}.tmp" "${URL}" \
    || die "wget failed for ${URL}"
mv "${DEST_FINAL}.tmp" "${DEST_FINAL}"

# ── GPG + checksum verification ───────────────────────────────────────────────
for EXT in ".DIGESTS" ".sha256" ".sha512"; do
    CHK_URL="${URL}${EXT}"
    CHK_FILE="${DEST_FINAL}${EXT}"
    if curl -fsSI "${CHK_URL}" &>/dev/null; then
        info "Downloading ${EXT}..."
        wget -q -O "${CHK_FILE}" "${CHK_URL}"
        break
    fi
done

if [[ -f "${DEST_FINAL}.DIGESTS" ]]; then
    info "Verifying GPG signature on DIGESTS..."
    gpg --verify "${DEST_FINAL}.DIGESTS" 2>/dev/null \
        && info "GPG OK." \
        || info "[warn] GPG verify failed or key not imported — skipping signature check."

    info "Verifying SHA512 checksum..."
    (cd "${DESTDIR}" && \
        grep -A1 SHA512 "${DEST_FINAL##*/}.DIGESTS" 2>/dev/null \
        | grep -v '^--' \
        | grep "${BASENAME}" \
        | sha512sum -c --status) \
    && info "SHA512 OK." \
    || info "[warn] SHA512 mismatch or no matching entry — proceed with caution."

elif [[ -f "${DEST_FINAL}.sha256" ]]; then
    info "Verifying SHA256..."
    (cd "${DESTDIR}" && sha256sum -c "${BASENAME}.sha256" --status) \
        && info "SHA256 OK." \
        || info "[warn] SHA256 mismatch."
fi

# Ensure canonical path matches
[[ "${DEST}" != "${DEST_FINAL}" ]] && ln -sf "${DEST_FINAL}" "${DEST}"

info "Done: ${DEST_FINAL}"
