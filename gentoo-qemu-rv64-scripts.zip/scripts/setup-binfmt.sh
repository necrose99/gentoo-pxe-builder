#!/bin/bash
# setup-binfmt.sh
# Registers qemu-user-static binfmt_misc entries for foreign arch binaries.
#
# Strategy:
#   - On an amd64 host: register riscv64 + arm64 interpreters
#   - On a native riscv64 or arm64 host: skip (kernel runs these natively)
#   - Uses the 'F' (fix-binary) flag so the interpreter path is resolved
#     at registration time and survives chroot pivots
#
# Requires:
#   - /proc/sys/fs/binfmt_misc mounted (host kernel, most distros do this)
#   - qemu-user-static installed (qemu-riscv64-static, qemu-aarch64-static)

set -euo pipefail

BINFMT_MISC="/proc/sys/fs/binfmt_misc"

die()  { echo "ERROR: $*" >&2; exit 1; }
info() { echo "[binfmt] $*"; }

# ── Detect host arch ─────────────────────────────────────────────────────────
HOST_ARCH=$(uname -m)
info "Host arch: ${HOST_ARCH}"

case "${HOST_ARCH}" in
    x86_64)
        NEED_RISCV64=1
        NEED_AARCH64=1
        ;;
    aarch64)
        NEED_RISCV64=1
        NEED_AARCH64=0   # native
        ;;
    riscv64)
        NEED_RISCV64=0   # native
        NEED_AARCH64=1
        ;;
    *)
        NEED_RISCV64=1
        NEED_AARCH64=1
        ;;
esac

# ── Ensure binfmt_misc is mounted ────────────────────────────────────────────
if [[ ! -f "${BINFMT_MISC}/register" ]]; then
    info "Mounting binfmt_misc..."
    mount -t binfmt_misc binfmt_misc "${BINFMT_MISC}" \
        || die "Cannot mount binfmt_misc. Ensure the host has CONFIG_BINFMT_MISC enabled."
fi

register_binfmt() {
    local name="$1"
    local magic="$2"
    local mask="$3"
    local interp="$4"
    # F = fix-binary (interp resolved at registration, survives chroot)
    # O = open-binary (kernel opens interp, not the child process)
    local flags="${5:-F}"
    local reg_file="${BINFMT_MISC}/${name}"

    if [[ -f "${reg_file}" ]]; then
        info "${name}: already registered ($(cat "${reg_file}" | head -1))"
        return 0
    fi

    if [[ ! -x "${interp}" ]]; then
        info "[skip] ${name}: interpreter not executable: ${interp}"
        return 0
    fi

    # binfmt_misc registration format:
    # :name:M:offset:magic:mask:interpreter:flags
    local entry=":${name}:M::${magic}:${mask}:${interp}:${flags}"
    echo "${entry}" > "${BINFMT_MISC}/register" \
        && info "Registered: ${name} → ${interp}" \
        || info "[warn] Failed to register ${name} (may already exist in kernel)"
}

# ── RISC-V 64 (lp64/lp64d) ───────────────────────────────────────────────────
# ELF64 little-endian, e_machine=0x00F3 (RISC-V)
# Bytes: 7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00 02 00 f3 00
if [[ "${NEED_RISCV64}" == "1" ]]; then
    QEMU_RISCV64=$(command -v qemu-riscv64-static 2>/dev/null \
        || find /usr -name "qemu-riscv64-static" 2>/dev/null | head -1 \
        || echo "/usr/bin/qemu-riscv64-static")
    register_binfmt \
        "qemu-riscv64" \
        "\x7fELF\x02\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\xf3\x00" \
        "\xff\xff\xff\xff\xff\xff\xff\x00\xff\xff\xff\xff\xff\xff\xff\xff\xfe\xff\xff\xff" \
        "${QEMU_RISCV64}"
fi

# ── AArch64 / ARM64 ──────────────────────────────────────────────────────────
# ELF64 little-endian, e_machine=0x00B7 (AArch64)
if [[ "${NEED_AARCH64}" == "1" ]]; then
    QEMU_AARCH64=$(command -v qemu-aarch64-static 2>/dev/null \
        || find /usr -name "qemu-aarch64-static" 2>/dev/null | head -1 \
        || echo "/usr/bin/qemu-aarch64-static")
    register_binfmt \
        "qemu-aarch64" \
        "\x7fELF\x02\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\xb7\x00" \
        "\xff\xff\xff\xff\xff\xff\xff\x00\xff\xff\xff\xff\xff\xff\xff\xff\xfe\xff\xff\xff" \
        "${QEMU_AARCH64}"
fi

info "binfmt_misc setup complete."
info "Active entries: $(ls "${BINFMT_MISC}" 2>/dev/null | grep -v '^register$\|^status$' | tr '\n' ' ')"
