#!/bin/bash
# qcow2-to-iso.sh  v2
# Converts a Gentoo qcow2 disk image → bootable EFI ISO.
#
# Adapted from brandonrc/qemu2liveiso, corrected for Gentoo specifics:
#   - Root filesystem is XFS (Gentoo qcow2 default)
#   - GRUB2 EFI (systemd-based Gentoo has no syslinux)
#   - grub.cfg follows the official Gentoo LiveUSB wiki exactly:
#       root=live:CDLABEL=<LABEL> rd.live.dir=/ rd.live.squashimg=image.squashfs cdroot
#   - squashfs image named "image.squashfs" (Gentoo convention, not squashfs.img)
#   - arch-chroot + dracut rebuild for rv64/arm64 on amd64 host via binfmt_misc
#   - genfstab written to /etc/fstab inside the ISO rootfs
#   - isoinfo used for inspection (app-cdr/cdrtools equivalent)
#   - xorriso + GRUB2 EFI for final ISO assembly
#   - All output to /output/ → ./output/ on host
#
# ENV:
#   QCOW2_PATH      path to qcow2 inside container  [/storage/gentoo-rv64.qcow2]
#   OUTPUT_ISO      destination ISO                  [/output/gentoo-rv64-live.iso]
#   ARCH            riscv64 | amd64 | arm64          [riscv64]
#   VOL_LABEL       ISO volume label (used in grub.cfg) [LiveUSB]
#   NBD_DEV         nbd device                        [/dev/nbd0]
#   SKIP_DRACUT     1 = skip initramfs rebuild        [0]
#   SQUASHFS_COMP   xz | zstd | lzo                  [xz]

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
QCOW2_PATH="${QCOW2_PATH:-/storage/gentoo-rv64.qcow2}"
OUTPUT_ISO="${OUTPUT_ISO:-/output/gentoo-rv64-live.iso}"
ARCH="${ARCH:-riscv64}"
VOL_LABEL="${VOL_LABEL:-LiveUSB}"
NBD_DEV="${NBD_DEV:-/dev/nbd0}"
SKIP_DRACUT="${SKIP_DRACUT:-0}"
SQUASHFS_COMP="${SQUASHFS_COMP:-xz}"

WORK_DIR="/tmp/isobuild"
MNT_ROOT="${WORK_DIR}/root"
ISO_STAGE="${WORK_DIR}/iso-stage"
BOOT_DIR="${ISO_STAGE}/boot"
EFI_DIR="${ISO_STAGE}/EFI/BOOT"

# ── Helpers ───────────────────────────────────────────────────────────────────
die()     { echo "ERROR: $*" >&2; cleanup; exit 1; }
info()    { echo "[qcow2-to-iso] $*"; }
section() { echo; echo "━━━ $* ━━━"; }

cleanup() {
    info "Cleanup: unmounting..."
    # Unmount bind mounts first
    for mp in proc sys dev/pts dev run; do
        umount -l "${MNT_ROOT}/${mp}" 2>/dev/null || true
    done
    umount -l "${MNT_ROOT}/boot"  2>/dev/null || true
    umount -l "${MNT_ROOT}"       2>/dev/null || true
    sleep 1
    qemu-nbd --disconnect "${NBD_DEV}" 2>/dev/null || true
    rmmod nbd 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# ── Validate ─────────────────────────────────────────────────────────────────
section "Validate"
[[ -f "${QCOW2_PATH}" ]] || die "QCOW2 not found: ${QCOW2_PATH}"

mkdir -p "${WORK_DIR}" "${MNT_ROOT}" \
         "${ISO_STAGE}" "${BOOT_DIR}/grub" \
         "${EFI_DIR}" "${ISO_STAGE}/LiveOS"

info "QCOW2      : ${QCOW2_PATH}"
info "Output ISO : ${OUTPUT_ISO}"
info "Arch       : ${ARCH}"
info "VOL_LABEL  : ${VOL_LABEL}"

# ── Step 1: nbd connect ───────────────────────────────────────────────────────
section "Step 1: NBD connect"
modprobe nbd max_part=16 2>/dev/null || true

qemu-nbd --disconnect "${NBD_DEV}" 2>/dev/null && sleep 1 || true

info "Connecting ${QCOW2_PATH} → ${NBD_DEV}"
qemu-nbd --connect="${NBD_DEV}" --read-only "${QCOW2_PATH}" \
    || die "qemu-nbd failed"
sleep 2

# Refresh partition table
partprobe "${NBD_DEV}" 2>/dev/null || true
sleep 1

# ── Step 2: Inspect layout ────────────────────────────────────────────────────
section "Step 2: Partition layout"

# isoinfo-style inspection via lsblk (isoinfo is for ISO9660, not qcow2 partitions)
info "Block layout:"
lsblk -o NAME,SIZE,FSTYPE,LABEL,PARTTYPE "${NBD_DEV}" 2>/dev/null || true

# Detect root partition (XFS preferred — Gentoo qcow2 default)
ROOT_PART=""
BOOT_PART=""   # separate /boot partition (vfat EFI or ext4)

# Iterate partitions ordered by size descending; pick largest XFS as root
while IFS= read -r line; do
    DEV=$(echo "${line}" | awk '{print $1}')
    FSTYPE=$(echo "${line}" | awk '{print $2}')
    LABEL=$(echo "${line}" | awk '{print $3}')

    case "${FSTYPE}" in
        xfs)
            # Gentoo default root
            [[ -z "${ROOT_PART}" ]] && ROOT_PART="/dev/${DEV}"
            ;;
        btrfs|ext4|ext3|f2fs)
            [[ -z "${ROOT_PART}" ]] && ROOT_PART="/dev/${DEV}"
            ;;
        vfat|fat32|fat16)
            # Likely EFI System Partition — use as /boot if no dedicated /boot
            BOOT_PART="/dev/${DEV}"
            ;;
    esac
done < <(lsblk -ln -o NAME,FSTYPE,LABEL "${NBD_DEV}" | awk 'NR>1 && $2!="" {print}')

[[ -z "${ROOT_PART}" ]] && die "Could not detect root partition (expected XFS). Check qcow2 layout."
info "Root partition : ${ROOT_PART} ($(lsblk -ln -o FSTYPE "${ROOT_PART}" | head -1))"
info "Boot partition : ${BOOT_PART:-<none — /boot on root>}"

# ── Step 3: Mount rootfs ──────────────────────────────────────────────────────
section "Step 3: Mount"
# XFS read-only mount (norecovery to avoid journalling issues on a snap)
FSTYPE_ROOT=$(lsblk -ln -o FSTYPE "${ROOT_PART}" | head -1)
case "${FSTYPE_ROOT}" in
    xfs)    mount -o ro,norecovery "${ROOT_PART}" "${MNT_ROOT}" ;;
    btrfs)  mount -o ro,noload "${ROOT_PART}" "${MNT_ROOT}" ;;
    *)      mount -o ro "${ROOT_PART}" "${MNT_ROOT}" ;;
esac
info "Mounted ${ROOT_PART} (${FSTYPE_ROOT}) → ${MNT_ROOT} [ro]"

if [[ -n "${BOOT_PART}" ]]; then
    mkdir -p "${MNT_ROOT}/boot"
    mount -o ro "${BOOT_PART}" "${MNT_ROOT}/boot" \
        && info "Mounted ${BOOT_PART} → ${MNT_ROOT}/boot [ro]" \
        || info "[warn] Could not mount ${BOOT_PART} as /boot"
fi

# ── Step 4: genfstab ─────────────────────────────────────────────────────────
section "Step 4: genfstab"
if command -v genfstab &>/dev/null; then
    FSTAB_OUT="${WORK_DIR}/fstab.generated"
    genfstab -U "${MNT_ROOT}" > "${FSTAB_OUT}" 2>/dev/null \
        && { info "Generated fstab:"; cat "${FSTAB_OUT}"; } \
        || info "[warn] genfstab failed (non-fatal)"
else
    info "[skip] genfstab not in PATH"
fi

# ── Step 5: Extract kernel + initramfs ───────────────────────────────────────
section "Step 5: Kernel + initramfs extraction"

BOOT_SRC="${MNT_ROOT}/boot"

# Gentoo kernel naming: gentoo, gentoo-dist, or vmlinuz-*
# RISC-V Gentoo may use "Image" or "Image.gz"
VMLINUZ=$(find "${BOOT_SRC}" \
    \( -name "vmlinuz-*" -o -name "gentoo" -o -name "Image" -o -name "Image.gz" \) \
    -not -name "*.old" 2>/dev/null | sort -V | tail -1)

INITRAMFS=$(find "${BOOT_SRC}" \
    \( -name "initramfs-*" -o -name "gentoo.igz" -o -name "initrd.img-*" \) \
    -not -name "*.old" 2>/dev/null | sort -V | tail -1)

[[ -z "${VMLINUZ}" ]]    && die "No kernel found in ${BOOT_SRC}. Contents: $(ls ${BOOT_SRC} 2>/dev/null)"
[[ -z "${INITRAMFS}" ]]  && die "No initramfs found in ${BOOT_SRC}."

info "Kernel    : ${VMLINUZ}"
info "Initramfs : ${INITRAMFS}"

cp "${VMLINUZ}"   "${BOOT_DIR}/gentoo"
cp "${INITRAMFS}" "${BOOT_DIR}/gentoo.igz"

# ── Step 6: Optional dracut rebuild (for live-boot modules) ─────────────────
section "Step 6: Dracut initramfs rebuild"

if [[ "${SKIP_DRACUT}" == "1" ]]; then
    info "SKIP_DRACUT=1 — using existing initramfs as-is."
else
    HOST_ARCH=$(uname -m)
    # For foreign arch roots, binfmt_misc must be active
    if [[ "${HOST_ARCH}" == "x86_64" && "${ARCH}" != "amd64" ]]; then
        info "Foreign arch rebuild: setting up binfmt_misc first..."
        /usr/local/bin/setup-binfmt.sh 2>/dev/null || true
    fi

    if command -v arch-chroot &>/dev/null && [[ -x "${MNT_ROOT}/usr/bin/dracut" ]]; then
        # Re-mount rw for dracut rebuild
        mount -o remount,rw "${MNT_ROOT}" 2>/dev/null || {
            # Can't remount ro nbd — mount a tmpfs overlay
            info "Cannot remount rw; using tmpfs overlay for dracut work..."
            mount -t tmpfs tmpfs "${MNT_ROOT}/tmp"
        }

        # Bind-mount essential pseudo-fs for chroot
        for mp in proc sys dev dev/pts run; do
            mkdir -p "${MNT_ROOT}/${mp}"
            mount --bind "/${mp}" "${MNT_ROOT}/${mp}" 2>/dev/null || true
        done

        KVER=$(ls "${MNT_ROOT}/lib/modules/" 2>/dev/null | sort -V | tail -1)
        info "Rebuilding initramfs for kernel: ${KVER}"

        arch-chroot "${MNT_ROOT}" dracut \
            --force \
            --kver "${KVER}" \
            --add "dmsquash-live livenet" \
            --filesystems "squashfs xfs btrfs ext4 overlayfs" \
            --no-hostonly \
            "/boot/gentoo.igz" \
        && {
            info "dracut rebuild OK"
            cp "${MNT_ROOT}/boot/gentoo.igz" "${BOOT_DIR}/gentoo.igz"
        } || info "[warn] dracut rebuild failed — using original initramfs"
    else
        info "[skip] arch-chroot or dracut not available in target rootfs"
        info "       Install sys-kernel/dracut in the Gentoo VM first for live-boot support."
    fi
fi

# ── Step 7: Build squashfs (named image.squashfs — Gentoo convention) ────────
section "Step 7: Build image.squashfs"

# Gentoo uses image.squashfs (not squashfs.img / rootfs.squashfs)
# See: https://wiki.gentoo.org/wiki/LiveUSB
SQUASHFS_OUT="${ISO_STAGE}/image.squashfs"

info "Compression: ${SQUASHFS_COMP}"
info "Squashing ${MNT_ROOT} → ${SQUASHFS_OUT} ..."
info "This may take a while..."

# Exclude ephemeral dirs and the boot dir (already copied separately)
mksquashfs "${MNT_ROOT}" "${SQUASHFS_OUT}" \
    -comp "${SQUASHFS_COMP}" \
    -noappend \
    -e "${MNT_ROOT}/proc/*" \
    -e "${MNT_ROOT}/sys/*" \
    -e "${MNT_ROOT}/dev/*" \
    -e "${MNT_ROOT}/run/*" \
    -e "${MNT_ROOT}/tmp/*" \
    -progress \
    -b 1M \
|| die "mksquashfs failed"

SQUASHFS_SIZE=$(du -sh "${SQUASHFS_OUT}" | awk '{print $1}')
info "image.squashfs: ${SQUASHFS_SIZE}"

# ── Step 8: GRUB2 grub.cfg (canonical Gentoo LiveUSB wiki format) ───────────
section "Step 8: grub.cfg"

# From https://wiki.gentoo.org/wiki/LiveUSB
# Key params:
#   root=live:CDLABEL=<LABEL>    → dracut live module finds the boot device by label
#   rd.live.dir=/                → squashfs is at root of the partition (not /LiveOS/)
#   rd.live.squashimg=image.squashfs  → Gentoo names it image.squashfs
#   cdroot                       → Gentoo-specific: mounts cdroot overlay
#   nodhcp secureconsole         → Gentoo livecd flags

cat > "${BOOT_DIR}/grub/grub.cfg" <<GRUBCFG
set default=0
set gfxpayload=keep
set timeout=10

insmod all_video

menuentry 'Boot Gentoo Live (${ARCH})' --class gnu-linux --class os {
    search --no-floppy --set=root --label ${VOL_LABEL}
    linux  /boot/gentoo nodhcp secureconsole \\
           root=live:CDLABEL=${VOL_LABEL} \\
           rd.live.dir=/ \\
           rd.live.squashimg=image.squashfs \\
           cdroot
    initrd /boot/gentoo.igz
}

menuentry 'Boot Gentoo Live (${ARCH}) — RAM copy' --class gnu-linux --class os {
    search --no-floppy --set=root --label ${VOL_LABEL}
    linux  /boot/gentoo nodhcp secureconsole \\
           root=live:CDLABEL=${VOL_LABEL} \\
           rd.live.dir=/ \\
           rd.live.squashimg=image.squashfs \\
           cdroot rd.live.ram=1
    initrd /boot/gentoo.igz
}

menuentry 'Boot Gentoo Live (${ARCH}) — debug shell' --class gnu-linux --class os {
    search --no-floppy --set=root --label ${VOL_LABEL}
    linux  /boot/gentoo nodhcp secureconsole \\
           root=live:CDLABEL=${VOL_LABEL} \\
           rd.live.dir=/ \\
           rd.live.squashimg=image.squashfs \\
           cdroot rd.break=mount
    initrd /boot/gentoo.igz
}
GRUBCFG

info "grub.cfg written (VOL_LABEL=${VOL_LABEL}, image.squashfs)"

# ── Step 9: GRUB2 EFI standalone binary ──────────────────────────────────────
section "Step 9: GRUB2 EFI binary"

case "${ARCH}" in
    riscv64)
        GRUB_TARGET="riscv64-efi"
        EFI_BINARY="BOOTRISCV64.EFI"
        ;;
    amd64|x86_64)
        GRUB_TARGET="x86_64-efi"
        EFI_BINARY="BOOTX64.EFI"
        ;;
    arm64|aarch64)
        GRUB_TARGET="arm64-efi"
        EFI_BINARY="BOOTAA64.EFI"
        ;;
    *)
        die "Unknown ARCH: ${ARCH}"
        ;;
esac

GRUB_MODULES="part_gpt part_msdos fat ext2 xfs squash4 loopback \
              linux normal configfile echo search search_label all_video"

info "Building GRUB ${GRUB_TARGET} standalone (${EFI_BINARY})..."

grub-mkstandalone \
    --format="${GRUB_TARGET}" \
    --output="${EFI_DIR}/${EFI_BINARY}" \
    --modules="${GRUB_MODULES}" \
    "boot/grub/grub.cfg=${BOOT_DIR}/grub/grub.cfg" \
|| die "grub-mkstandalone failed for ${GRUB_TARGET}"

info "EFI binary: ${EFI_DIR}/${EFI_BINARY}"

# ── Step 10: EFI partition image (El Torito) ──────────────────────────────────
section "Step 10: EFI system partition image"

EFI_IMG="${WORK_DIR}/efi.img"
EFI_SUBDIR="EFI/BOOT"

dd if=/dev/zero of="${EFI_IMG}" bs=1M count=32 status=none
mkfs.vfat -n "EFIBOOT" "${EFI_IMG}"
mmd  -i "${EFI_IMG}" "::/${EFI_SUBDIR}" 2>/dev/null || \
mmd  -i "${EFI_IMG}" "::EFI" && mmd -i "${EFI_IMG}" "::EFI/BOOT" 2>/dev/null || true
mcopy -i "${EFI_IMG}" "${EFI_DIR}/${EFI_BINARY}" "::${EFI_SUBDIR}/${EFI_BINARY}"
cp "${EFI_IMG}" "${ISO_STAGE}/efi.img"

# ── Step 11: xorriso → ISO ────────────────────────────────────────────────────
section "Step 11: xorriso ISO assembly"

info "ISO layout:"
find "${ISO_STAGE}" -type f | sort | while read -r f; do
    printf "  %-60s %s\n" "${f#${ISO_STAGE}}" "$(du -sh "${f}" | awk '{print $1}')"
done

info "Building ${OUTPUT_ISO} ..."

xorriso -as mkisofs \
    -volid "${VOL_LABEL}" \
    -volset-id "Gentoo Linux ${ARCH} Live" \
    -rational-rock \
    -joliet \
    -full-iso9660-filenames \
    -eltorito-alt-boot \
      -e efi.img \
      -no-emul-boot \
    -isohybrid-gpt-basdat \
    -output "${OUTPUT_ISO}" \
    "${ISO_STAGE}" \
|| die "xorriso failed"

ISO_SIZE=$(du -sh "${OUTPUT_ISO}" | awk '{print $1}')

section "Complete"
info "ISO       : ${OUTPUT_ISO}"
info "Size      : ${ISO_SIZE}"
info "Host path : ./output/$(basename "${OUTPUT_ISO}")"
echo
echo "── Test boot (QEMU) ──────────────────────────────────────────"
case "${ARCH}" in
    riscv64)
        BIOS=$(find /usr -name "fw_jump.elf" 2>/dev/null | head -1 || echo "/usr/lib/.../fw_jump.elf")
        echo "qemu-system-riscv64 -machine virt -m 2G -bios ${BIOS} \\"
        echo "  -drive file=${OUTPUT_ISO},format=raw,if=none,id=iso,readonly=on \\"
        echo "  -device virtio-blk-device,drive=iso -nographic -serial mon:stdio"
        ;;
    amd64|x86_64)
        echo "qemu-system-x86_64 -machine q35 -m 2G -enable-kvm \\"
        echo "  -drive if=pflash,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE.fd \\"
        echo "  -cdrom ${OUTPUT_ISO} -boot d"
        ;;
    arm64|aarch64)
        echo "qemu-system-aarch64 -machine virt -cpu cortex-a72 -m 2G \\"
        echo "  -bios /usr/share/qemu-efi-aarch64/QEMU_EFI.fd \\"
        echo "  -cdrom ${OUTPUT_ISO} -boot d -nographic"
        ;;
esac

# ── Bonus: isoinfo inspection ─────────────────────────────────────────────────
if command -v isoinfo &>/dev/null; then
    echo
    info "isoinfo -d (ISO9660 header):"
    isoinfo -d -i "${OUTPUT_ISO}" 2>/dev/null | grep -E "Volume id|System id|Logical|El Torito" || true
fi
