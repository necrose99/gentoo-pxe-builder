#!/bin/bash
# rv64-start.sh
# Entrypoint for the qemu-rv64 container.
# 1. Registers binfmt_misc (riscv64/arm64) when running on amd64 host
# 2. Fetches Gentoo rv64 installer qcow2 if not cached
# 3. Creates a persistent main disk qcow2 if absent
# 4. Launches qemu-system-riscv64 with OpenSBI + U-Boot EFI firmware

set -euo pipefail

QCOW2_URL="${RV64_QCOW2_URL:-https://distfiles.gentoo.org/releases/riscv/autobuilds/20260406T163102Z/di-rv64_lp64d-console-20260406T163102Z.qcow2}"
STORAGE="/storage"
OUTPUT_DIR="${OUTPUT_DIR:-/output}"
DISK_SIZE="${DISK_SIZE:-32G}"
RAM_SIZE="${RAM_SIZE:-4G}"
CPU_CORES="${CPU_CORES:-4}"

INSTALLER_QCOW2="${STORAGE}/$(basename "${QCOW2_URL}")"
MAIN_DISK="${STORAGE}/gentoo-rv64.qcow2"

info()    { echo "[rv64-start] $*"; }
section() { echo; echo "══ $* ══"; }

# ── binfmt_misc (only needed when container runs on amd64) ────────────────────
section "binfmt_misc"
/usr/local/bin/setup-binfmt.sh \
    || info "[warn] binfmt_misc setup failed — chroot into rv64 rootfs won't work"

# ── Fetch installer qcow2 ────────────────────────────────────────────────────
section "Installer qcow2"
/usr/local/bin/fetch-rv64-qcow2.sh "${QCOW2_URL}" "${INSTALLER_QCOW2}"

# ── Create main disk ─────────────────────────────────────────────────────────
section "Main disk"
if [[ ! -f "${MAIN_DISK}" ]]; then
    info "Creating ${DISK_SIZE} main disk: ${MAIN_DISK}"
    qemu-img create -f qcow2 "${MAIN_DISK}" "${DISK_SIZE}"
else
    DISK_INFO=$(qemu-img info --output=human "${MAIN_DISK}" 2>/dev/null | head -4 || true)
    info "Existing disk found:"
    echo "${DISK_INFO}"
fi

# ── Locate firmware ──────────────────────────────────────────────────────────
section "Firmware"

# OpenSBI fw_jump.elf — required
OPENSBI_CANDIDATES=(
    "/usr/lib/riscv64-linux-gnu/opensbi/generic/fw_jump.elf"
    "/usr/share/opensbi/lp64/generic/firmware/fw_jump.elf"
    "/usr/lib/opensbi/fw_jump.elf"
)
OPENSBI=""
for f in "${OPENSBI_CANDIDATES[@]}"; do
    [[ -f "$f" ]] && OPENSBI="$f" && break
done
[[ -z "${OPENSBI}" ]] && OPENSBI=$(find /usr -name "fw_jump.elf" 2>/dev/null | head -1)
[[ -z "${OPENSBI}" ]] && { echo "ERROR: OpenSBI fw_jump.elf not found."; exit 1; }
info "OpenSBI : ${OPENSBI}"

# U-Boot EFI — optional but strongly recommended for UEFI boot
UBOOT_CANDIDATES=(
    "/usr/lib/u-boot/qemu-riscv64_smode/u-boot.bin"
    "/usr/share/u-boot/qemu-riscv64/u-boot.bin"
)
UBOOT=""
for f in "${UBOOT_CANDIDATES[@]}"; do
    [[ -f "$f" ]] && UBOOT="$f" && break
done
[[ -z "${UBOOT}" ]] && UBOOT=$(find /usr -name "u-boot.bin" -path "*riscv*" 2>/dev/null | head -1)
if [[ -n "${UBOOT}" ]]; then
    info "U-Boot  : ${UBOOT}"
    UBOOT_ARGS=(-device "loader,file=${UBOOT},addr=0x80200000")
else
    info "U-Boot  : not found — UEFI boot unavailable (GRUB2 won't work without it)"
    UBOOT_ARGS=()
fi

# ── KVM detection ─────────────────────────────────────────────────────────────
section "Acceleration"
KVM_ARGS=()
if [[ -e /dev/kvm ]]; then
    # RISC-V KVM needs H-extension (hypervisor extension) in host CPU
    # /proc/cpuinfo isa field will contain 'h' if H-ext is present
    if grep -qE "isa\s*:.*h" /proc/cpuinfo 2>/dev/null; then
        KVM_ARGS=(-accel kvm -cpu host)
        info "KVM acceleration enabled (H-extension present)"
    else
        KVM_ARGS=(-accel tcg,thread=multi)
        info "KVM available but H-extension absent — using TCG multi-thread"
    fi
else
    KVM_ARGS=(-accel tcg,thread=multi)
    info "No /dev/kvm — using TCG (slow but functional for install/build work)"
fi

# ── Network ───────────────────────────────────────────────────────────────────
# user-mode networking; hostfwd for SSH passthrough (container port 22 → host 2222)
NET_ARGS=(
    -netdev "user,id=net0,hostfwd=tcp::22-:22,hostname=gentoo-rv64"
    -device "virtio-net-device,netdev=net0"
)

# ── Drive layout ──────────────────────────────────────────────────────────────
# Drive 0: installer qcow2 (read-only)  — contains Gentoo di installer
# Drive 1: main disk (read-write)       — install Gentoo here
DRIVE_ARGS=(
    -drive "file=${INSTALLER_QCOW2},format=qcow2,if=none,id=installer,readonly=on"
    -device "virtio-blk-device,drive=installer"
    -drive "file=${MAIN_DISK},format=qcow2,if=none,id=maindisk"
    -device "virtio-blk-device,drive=maindisk"
)

# ── Launch ────────────────────────────────────────────────────────────────────
section "Launch qemu-system-riscv64"
info "RAM: ${RAM_SIZE}  CPUs: ${CPU_CORES}  Disk: ${DISK_SIZE}"
info "Web VNC  → http://HOST:8007"
info "SSH      → ssh -p 2222 root@HOST  (once Gentoo is installed)"
info "Serial   → docker compose logs -f qemu-rv64"

exec qemu-system-riscv64 \
    -machine virt \
    -smp "${CPU_CORES}" \
    -m "${RAM_SIZE}" \
    "${KVM_ARGS[@]}" \
    -bios "${OPENSBI}" \
    "${UBOOT_ARGS[@]}" \
    "${DRIVE_ARGS[@]}" \
    "${NET_ARGS[@]}" \
    -device virtio-rng-device \
    -nographic \
    -serial mon:stdio \
    "$@"
