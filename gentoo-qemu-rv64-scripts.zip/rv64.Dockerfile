# rv64.Dockerfile
# Extends qemux/qemu with:
#   - qemu-system-riscv64 + OpenSBI + U-Boot firmware
#   - qemu-user-static + binfmt_misc (for chroot into rv64/arm64 rootfs on amd64 host)
#   - arch-install-scripts  → arch-chroot, genfstab
#   - squashfs-tools, xorriso, cdrtools (isoinfo/mkisofs), mtools
#   - grub2 EFI targets: x86_64-efi, arm64-efi, riscv64-efi
#   - btrfs-progs, xfsprogs, e2fsprogs  (Gentoo qcow2 default root is XFS)
#   - autofs, nfs-utils, cifs-utils, libnss-winbind (net-fs)
#   - dracut-ng for initramfs rebuild inside chroot
#
# Note: Gentoo qcow2 disk images use XFS as the default root filesystem
#       (sys-fs/xfsprogs), with GRUB2 EFI and systemd init.

FROM qemux/qemu:latest

LABEL maintainer="necrose99"
LABEL description="Gentoo RISC-V 64 QEMU + multi-arch ISO builder"

# ── Core system + QEMU rv64 emulation ────────────────────────────────────────
RUN apt-get update && apt-get install -y --no-install-recommends \
    \
    # QEMU RISC-V system emulator
    qemu-system-riscv \
    # OpenSBI firmware (fw_jump.elf, fw_dynamic.elf)
    opensbi \
    # U-Boot EFI firmware for qemu-riscv64_smode
    u-boot-qemu \
    # QEMU disk image utilities (qemu-img, qemu-nbd)
    qemu-utils \
    # QEMU user-mode static binaries for binfmt_misc
    qemu-user-static \
    \
    # ── Filesystem tools ─────────────────────────────────────────────────
    # XFS (Gentoo default root in qcow2 images)
    xfsprogs \
    # btrfs (btrfsmaintenance, btrfs-progs equivalent)
    btrfs-progs \
    btrfsmaintenance \
    # ext2/3/4
    e2fsprogs \
    # dosfstools for EFI FAT partition
    dosfstools \
    # nbd block device (for qcow2 mount)
    nbd-client \
    \
    # ── squashfs + ISO toolchain ──────────────────────────────────────────
    squashfs-tools \
    xorriso \
    mtools \
    # cdrtools: isoinfo, mkisofs, cdrecord (app-cdr/cdrtools equiv)
    genisoimage \
    \
    # ── GRUB2 EFI targets ────────────────────────────────────────────────
    grub2-common \
    grub-efi-amd64-bin \
    grub-efi-arm64-bin \
    grub-efi-riscv64-bin \
    grub-pc-bin \
    \
    # ── arch-install-scripts: arch-chroot + genfstab ─────────────────────
    arch-install-scripts \
    \
    # ── Network filesystems (net-fs equivalent) ───────────────────────────
    # autofs (net-fs/autofs)
    autofs \
    # nfs-utils
    nfs-common \
    nfs-kernel-server \
    # cifs-utils (SMB/CIFS)
    cifs-utils \
    \
    # ── General utilities ─────────────────────────────────────────────────
    wget curl rsync \
    parted gdisk \
    util-linux \
    bash \
    python3 python3-pip \
    xz-utils lzma \
    zstd \
    cpio \
    libguestfs-tools \
    \
  && rm -rf /var/lib/apt/lists/*

# ── binfmt_misc setup script ─────────────────────────────────────────────────
COPY scripts/setup-binfmt.sh      /usr/local/bin/setup-binfmt.sh

# ── Runtime scripts ───────────────────────────────────────────────────────────
COPY scripts/rv64-start.sh        /usr/local/bin/rv64-start.sh
COPY scripts/fetch-rv64-qcow2.sh  /usr/local/bin/fetch-rv64-qcow2.sh

RUN chmod +x \
    /usr/local/bin/setup-binfmt.sh \
    /usr/local/bin/rv64-start.sh \
    /usr/local/bin/fetch-rv64-qcow2.sh

RUN mkdir -p /storage /output /tmp/qemu-work

VOLUME ["/storage", "/output"]

ENTRYPOINT ["/usr/local/bin/rv64-start.sh"]
